import urllib,os
names=open('filename.txt').readlines()
urls=open('url.txt').readlines()
for i in range(len(names)):
    url=urls[i].strip()
    name='./'+names[i].strip()
    if(os.path.isfile(name)):
        continue
    print 'download '+name
    if(not os.path.isdir('./'+os.path.dirname(name))):
        os.makedirs("./"+os.path.dirname(name))
    fp=open(name,'wb')
    data=urllib.urlopen(url).read()
    fp.write(data)
    fp.close()
    #urllib.urlretrieve(url,name)
    
